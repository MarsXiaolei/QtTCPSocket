/*
Develop environment: Visual Studio 2015 + Qt5.9.6
*/
#include "QtSocketClient.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
	Client w;
    w.show();
    return a.exec();
}
